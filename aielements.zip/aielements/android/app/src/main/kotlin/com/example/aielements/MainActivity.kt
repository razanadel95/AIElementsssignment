package com.example.aielements

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
